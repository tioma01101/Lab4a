package pl.lublin.wsei.java.cwiczenia;

import javafx.scene.image.ImageView;

public class ImgViewer {

    public ImageView imgView;
}
